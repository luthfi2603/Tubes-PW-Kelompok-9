<div class="container mtNav">
    <div class="card col-9 marAdmin p-0">
        <div class="card-header bg-ijo2">
            <h4 class="card-title text-center mb-0 text-white">Halaman Admin</h4>
        </div>
        <div class="row my-4 text-center">
            <div class="col">
                <a class="btn btn-info text-white" href="?p=adminAkun">Data Akun</a>
            </div>
            <div class="col">
                <a class="btn btn-primary text-white" href="?p=adminProduk">Data Produk</a>
            </div>
            <div class="col">
                <a class="btn btn-success text-white" href="?p=adminPesanan">Pesanan</a>
            </div>
        </div>
    </div>
</div>