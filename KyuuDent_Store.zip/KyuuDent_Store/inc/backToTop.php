<div class='back-to-top'>
    <svg viewBox="0 0 20 20">
        <polyline points="4 13 10 7 16 13"></polyline>
    </svg>
</div>