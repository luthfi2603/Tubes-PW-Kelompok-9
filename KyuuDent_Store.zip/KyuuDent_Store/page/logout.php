<?php
    keluar();
    echo"
        <script>
            alert('berhasil keluar');
            document.location.href = 'inc/..';
        </script>
    ";
?>